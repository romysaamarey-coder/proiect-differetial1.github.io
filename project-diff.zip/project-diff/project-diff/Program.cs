﻿using System;
using System.Collections.Generic;

class Program
{
    const string Pad = "    "; 

    static double F(double x)
    {
        return Math.Pow(x, 3) - 2 * x - 5;
    }

    static double DF(double x)
    {
        return 3 * x * x - 2;
    }

    static void WriteLinePad(string text = "")
    {
        Console.WriteLine(Pad + text);
    }

    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        double x = 2.0;
        double tolerance = 0.000001;
        int maxIterations = 50;

        List<double> values = new List<double>();

        Console.WriteLine();
        WriteLinePad("=================================================================");
        WriteLinePad("                     NEWTON-RAPHSON METHOD                       ");
        WriteLinePad("=================================================================\n\n");
        WriteLinePad("Function     : f(x) = x^3 - 2x - 5");
        WriteLinePad("Derivative   : f'(x) = 3x^2 - 2");
        WriteLinePad($"Initial Guess: X0 = {x}");
        WriteLinePad($"Tolerance    : {tolerance}\n");
        WriteLinePad("-----------------------------------------------------------------");
        WriteLinePad($"{"Iter",-5} {"X(i)",-12} {"f(Xi)",-14} {"f'(Xi)",-14} {"Next X",-12}");
        WriteLinePad("-----------------------------------------------------------------");

        values.Add(x);

        bool converged = false;
        int iterations = 0;

        for (int i = 0; i < maxIterations; i++)
        {
            double fx = F(x);
            double dfx = DF(x);

            if (Math.Abs(dfx) < 1e-14)
            {
                WriteLinePad("Error: Derivative is zero.");
                break;
            }

            double nextX = x - fx / dfx;
            double error = Math.Abs(nextX - x);

            WriteLinePad($"{i + 1,-5} {x,-12:F6} {fx,-14:F6} {dfx,-14:F6} {nextX,-12:F6}");

            values.Add(nextX);
            iterations = i + 1;

            if (Math.Abs(F(nextX)) < tolerance && error < tolerance)
            {
                x = nextX;
                converged = true;
                break;
            }

            x = nextX;
        }

        WriteLinePad("-----------------------------------------------------------------");

        if (converged)
        {
            WriteLinePad();
            WriteLinePad("RESULT:");
            WriteLinePad($"  Approximate Root     = {x:F8}");
            WriteLinePad($"  f(Root)              = {F(x):F10}");
            WriteLinePad($"  Number of Iterations = {iterations}");
            WriteLinePad();
        }
        else
        {
            WriteLinePad();
            WriteLinePad("Method did not converge.");
            WriteLinePad($"  Last approximation   = {x:F8}");
            WriteLinePad();
        }

        WriteLinePad("-----------------------------------------------------------------");
        WriteLinePad("FUNCTION GRAPH: y = x^3 - 2x - 5");
        WriteLinePad("Legend:  • = Curve    O = Iteration Point    R = Root");
        WriteLinePad("-----------------------------------------------------------------\n");

        DrawGraph(values, x, converged);

        WriteLinePad("\nPress any key to exit...");
        Console.ReadKey();
    }

    static void DrawGraph(List<double> points, double root, bool converged)
    {
        int width = 61;  
        int height = 25; 

        double xmin = 1.0;
        double xmax = 3.0;

        double ymin = -7.0;
        double ymax = 17.0;

        char[,] graph = new char[height, width];

        for (int row = 0; row < height; row++)
            for (int col = 0; col < width; col++)
                graph[row, col] = ' ';

        int zeroRow = (int)Math.Round((ymax - 0.0) * (height - 1) / (ymax - ymin));

        for (int col = 0; col < width; col++)
            graph[zeroRow, col] = '─';

        for (int col = 0; col < width; col++)
        {
            double xVal = xmin + col * (xmax - xmin) / (width - 1);
            double yVal = F(xVal);

            int row = (int)Math.Round((ymax - yVal) * (height - 1) / (ymax - ymin));

            if (row >= 0 && row < height)
                graph[row, col] = '•';
        }

        foreach (double pt in points)
        {
            double yVal = F(pt);

            int col = (int)Math.Round((pt - xmin) * (width - 1) / (xmax - xmin));
            int row = (int)Math.Round((ymax - yVal) * (height - 1) / (ymax - ymin));

            if (col >= 0 && col < width && row >= 0 && row < height)
                graph[row, col] = 'O';
        }

        if (converged)
        {
            int rootCol = (int)Math.Round((root - xmin) * (width - 1) / (xmax - xmin));
            if (rootCol >= 0 && rootCol < width)
                graph[zeroRow, rootCol] = 'R';
        }

        for (int row = 0; row < height; row++)
        {
            double yLabel = ymax - row * (ymax - ymin) / (height - 1);

            string yText = (row % 2 == 0 || row == zeroRow) ? $"{yLabel,6:F1}" : "      ";

            Console.Write($"{Pad}{yText} │");
            for (int col = 0; col < width; col++)
                Console.Write(graph[row, col]);
            Console.WriteLine();
        }

        WriteLinePad("       └" + new string('─', width));

        WriteLinePad("        1.0            1.5            2.0            2.5            3.0");
    }
}
